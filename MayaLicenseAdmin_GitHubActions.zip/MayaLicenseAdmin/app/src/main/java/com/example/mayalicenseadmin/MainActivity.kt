package com.example.mayalicenseadmin

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LicenseItem(val key: String, var status: String, val created: String)

class MainActivity : Activity() {
    private val items = mutableListOf<LicenseItem>()
    private lateinit var listBox: LinearLayout
    private lateinit var countText: TextView
    private val bg = Color.rgb(14, 18, 32)
    private val panel = Color.rgb(25, 32, 52)
    private val accent = Color.rgb(98, 130, 255)
    private val white = Color.rgb(244, 246, 255)
    private val muted = Color.rgb(172, 182, 207)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(12))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("MAYA", 13, accent, true))
        content.addView(label("License Admin", 29, white, true))
        content.addView(label("Authorized key management • Demo mode", 13, muted, false).apply {
            setPadding(0, dp(4), 0, dp(18))
        })

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(panel, dp(18))
        }
        stats.addView(label("LICENSE KEYS", 12, muted, true))
        countText = label("0 total  •  0 active  •  0 revoked", 17, white, true)
        stats.addView(countText)
        content.addView(stats, marginParams(bottom = 16))

        val addButton = Button(this).apply {
            text = "＋  Generate demo key"
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(accent, dp(14))
            setOnClickListener { generateKey() }
        }
        content.addView(addButton, marginParams(bottom = 10))

        val note = label(
            "Important: This standalone demo stores keys only on this device. It does not activate, unlock, or modify Maya. For real licenses, connect a backend you own and verify keys server-side.",
            13, muted, false
        ).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(38, 43, 61), dp(12))
        }
        content.addView(note, marginParams(bottom = 18))
        content.addView(label("KEYS", 13, muted, true).apply {
            setPadding(0, 0, 0, dp(8))
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)
        setContentView(root)
        refresh()
    }

    private fun generateKey() {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        fun segment() = (1..4).map { alphabet[random.nextInt(alphabet.length)] }.joinToString("")
        val key = "DEMO-${segment()}-${segment()}-${segment()}"
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        items.add(0, LicenseItem(key, "ACTIVE (LOCAL)", time))
        refresh()
        Toast.makeText(this, "Demo key generated on this device", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val active = items.count { it.status.startsWith("ACTIVE") }
        countText.text = "${items.size} total  •  $active active  •  ${items.size - active} revoked"
        if (items.isEmpty()) {
            val empty = label("No keys yet. Generate a demo key to try the dashboard.", 14, muted, false)
            empty.setPadding(dp(4), dp(16), dp(4), dp(16))
            listBox.addView(empty)
        }
        items.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(panel, dp(14))
            }
            val keyView = label(item.key, 15, white, true)
            card.addView(keyView)
            card.addView(label("${item.status}  •  ${item.created}", 12, muted, false).apply {
                setPadding(0, dp(5), 0, dp(8))
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val copy = Button(this).apply {
                text = "Copy"
                textSize = 12f
                setOnClickListener {
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Demo license key", item.key))
                    Toast.makeText(this@MainActivity, "Copied demo key", Toast.LENGTH_SHORT).show()
                }
            }
            val revoke = Button(this).apply {
                text = if (item.status.startsWith("REVOKED")) "Revoked" else "Revoke"
                textSize = 12f
                isEnabled = !item.status.startsWith("REVOKED")
                setOnClickListener {
                    item.status = "REVOKED (LOCAL)"
                    refresh()
                }
            }
            actions.addView(copy, LinearLayout.LayoutParams(0, dp(44), 1f))
            actions.addView(revoke, LinearLayout.LayoutParams(0, dp(44), 1f))
            card.addView(actions)
            listBox.addView(card, marginParams(bottom = 10))
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun marginParams(bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
