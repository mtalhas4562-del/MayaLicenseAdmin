# Maya License Admin (Android project)

A standalone Android Studio starter project for **authorized license/access-key administration**.

## Current features
- Dashboard counters
- Generate random demo keys
- Copy demo keys
- Revoke demo keys locally
- No permissions or network access required

## Important limitations
This is a local prototype. Keys are stored in memory and disappear when the app process restarts. “ACTIVE (LOCAL)” means only that the item is active in this demo UI; it does not grant access to Maya or any other app. This project does not bypass licensing, alter the uploaded APK, or recover private vendor keys.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually under `app/build/outputs/apk/debug/app-debug.apk`.

For a real production system, use a backend you control, authenticated admin accounts, role-based permissions, audit logs, rate limits, and server-side license validation. Do not put a signing secret or master admin key inside the APK.
